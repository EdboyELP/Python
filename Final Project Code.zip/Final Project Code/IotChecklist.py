print("IoT Security Checklist\n")

strengthen_access_management = input("Strengthen Access Management (Press Enter): ")
if strengthen_access_management.lower() == "":
    user_id = input("Is User ID made essential for IoT device users? (Y/N): ")
    rbac = input("Is Role-based access control (RBAC) used for granting permissions? (Y/N): ")

check_open_ports = input("\nCheck for open ports (Press Enter): ")
if check_open_ports.lower() == "":
    disconnect_unused_ports = input("Are unused ports disconnected? (Y/N): ")
    monitor_open_ports = input("Are open ports being monitored? (Y/N): ")
    scan_traffic = input("Are tools being used to scan network traffic through open ports? (Y/N): ")

enable_encryption_passwords = input("\nEnable encryption and strong passwords (Press Enter): ")
if enable_encryption_passwords.lower() == "":
    encrypt_data = input("Is data being transferred or stored in an encrypted format? (Y/N): ")
    strong_passwords = input("Are strong passwords being used? (Y/N): ")
    two_factor_auth = input("Is 2-factor authentication enabled? (Y/N): ")

segment_iot_network = input("\nSegment the IoT Network (Press Enter): ")
if segment_iot_network.lower() == "":
    separate_network = input("Is the IoT network separated from the core network? (Y/N): ")
    install_firewall = input("Is a firewall installed to block attackers from penetrating the core network? (Y/N): ")

keep_firmware_updated = input("\nKeep the IoT Firmware up to date (Press Enter): ")
if keep_firmware_updated.lower() == "":
    update_firmware = input("Is IoT firmware being regularly updated? (Y/N): ")
    remove_expired_devices = input("Are devices being removed promptly when they can no longer be updated? (Y/N): ")
    enable_auto_update = input("Is auto-update enabled to ensure no new updates are missed? (Y/N): ")
