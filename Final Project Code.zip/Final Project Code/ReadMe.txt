Open terminal
Navigate terminal to location of IoTChecklist
Type command "python3 IoTChecklist.py" and press enter
Follow commands on screen(Such as "Press Enter" and "Y/N")

END